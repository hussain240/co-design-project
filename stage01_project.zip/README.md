# HWSW Co-Design Project — pyperformance Optimization & Hardware Acceleration

Analysis and optimization of pyperformance benchmarks on the course VM (Ubuntu 22.04, Python 3.10), and a hardware accelerator proposal.

## Plan

1. Choose two pyperformance benchmarks and profile them (perf, flame graphs).
2. Optimize them by at least 7% and measure with pyperformance.
3. Propose a hardware accelerator for their hot code.
