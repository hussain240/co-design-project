# HWSW Co-Design Project — pyperformance Optimization & Hardware Acceleration

Analysis and optimization of pyperformance benchmarks on the course VM (Ubuntu 22.04, Python 3.10), and a hardware accelerator proposal.

## Status

| Part | Status |
|---|---|
| nbody | optimized, not measured yet |

## Repository structure

```
script_nbody.sh                                nbody: setup, baseline, optimized run, comparison, perf, flame graphs
benchmarks/nbody/original/run_benchmark.py     unmodified pyperformance bm_nbody
benchmarks/nbody/optimized/run_benchmark.py    optimized nbody (same API, same output)
benchmarks/nbody/manifest/                     pyperformance manifest for the optimized version
benchmarks/nbody/verify_nbody.py               correctness check (energy / state)
benchmarks/nbody/profile_nbody.py              single-process driver for perf
benchmarks/nbody/bytecode_count_nbody.py       executed bytecodes per step
```

## How to run

On the course VM (Ubuntu 22.04, Python 3.10, perf, python3-dbg):

```bash
./script_nbody.sh                 # first run (installs the tools)
SKIP_SETUP=1 ./script_nbody.sh    # later runs
```
