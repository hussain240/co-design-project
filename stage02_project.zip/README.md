# HWSW Co-Design Project — pyperformance Optimization & Hardware Acceleration

Analysis and optimization of pyperformance benchmarks on the course VM (Ubuntu 22.04, Python 3.10), and a hardware accelerator proposal.

## Status

| Part | Status |
|---|---|
| nbody | analysis in progress |

## Repository structure

```
benchmarks/nbody/original/run_benchmark.py     unmodified pyperformance bm_nbody
benchmarks/nbody/verify_nbody.py               correctness check (energy / state)
benchmarks/nbody/profile_nbody.py              single-process driver for perf
```

## How to run

On the course VM (Ubuntu 22.04, Python 3.10, perf, python3-dbg):

```bash
python3 benchmarks/nbody/verify_nbody.py
pyperformance run -b nbody -o baseline.json
```
