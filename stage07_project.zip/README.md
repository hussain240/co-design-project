# HWSW Co-Design Project — pyperformance Optimization & Hardware Acceleration

Analysis and optimization of pyperformance benchmarks on the course VM (Ubuntu 22.04, Python 3.10), and a hardware accelerator proposal.

## Status

| Part | Status |
|---|---|
| nbody | measured on the VM: 1.69x |
| raytrace | analysis in progress |

## Repository structure

```
script_nbody.sh                                nbody: setup, baseline, optimized run, comparison, perf, flame graphs
benchmarks/nbody/original/run_benchmark.py     unmodified pyperformance bm_nbody
benchmarks/nbody/optimized/run_benchmark.py    optimized nbody (same API, same output)
benchmarks/nbody/manifest/                     pyperformance manifest for the optimized version
benchmarks/nbody/verify_nbody.py               correctness check (energy / state)
benchmarks/nbody/profile_nbody.py              single-process driver for perf
benchmarks/nbody/bytecode_count_nbody.py       executed bytecodes per step
benchmarks/nbody/ablation_nbody.py             each optimization measured separately
benchmarks/nbody/results/                      VM measurements (json, perf stat, perf report)
benchmarks/nbody/flamegraphs/                  flame graphs (original / optimized)
benchmarks/raytrace/original/run_benchmark.py  unmodified pyperformance bm_raytrace
benchmarks/raytrace/verify_raytrace.py         image comparison (SHA-256)
benchmarks/raytrace/profile_raytrace.py        single-process driver for perf
benchmarks/raytrace/callcount_raytrace.py      Python calls / allocations per render
```

## How to run

On the course VM (Ubuntu 22.04, Python 3.10, perf, python3-dbg):

```bash
./script_nbody.sh                 # first run (installs the tools)
SKIP_SETUP=1 ./script_nbody.sh    # later runs
python3 benchmarks/raytrace/verify_raytrace.py
```
